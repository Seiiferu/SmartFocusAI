# src/detection/object_detector.py
